/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2010 BiBiServ Curator Team, http://bibiserv.cebitec.uni-bielefeld.de,
 * All rights reserved.
 *
 * The contents of this file are subject to the terms of the Common
 * Development and Distribution License("CDDL") (the "License"). You
 * may not use this file except in compliance with the License. You can
 * obtain a copy of the License at http://www.sun.com/cddl/cddl.html
 *
 * See the License for the specific language governing permissions and
 * limitations under the License.  When distributing the software, include
 * this License Header Notice in each file.  If applicable, add the following
 * below the License Header, with the fields enclosed by brackets [] replaced
 *  by your own identifying information:
 *
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Contributor(s):
 *
 */

package de.unibi.techfak.bibiserv.tools.pkiss;

import java.io.IOException;
import java.util.Map;
import org.apache.log4j.Logger;
import javax.faces.context.FacesContext;

/**
 * A bean used to reset the session for just this tool.
 * @author Thomas Gatter - tgatter(at)cebitec.uni-bielefeld.de
 */
public class pkiss_reset {

    private static Logger log = Logger.getLogger(pkiss_reset.class);


    public void reset() {
        
       String[] beanIds = {"awsBean", "toolBean_pkiss_download", "pkiss_input_rna_secondary_structure", "pkiss_input_rna_sequences", "pkiss_input_rna_sequence", "pkiss_input_rna_family", "pkiss_function", "pkiss_function_mfe_param", "pkiss_function_mfe_result", "pkiss_function_mfe_resulthandler", "pkiss_function_mfe_execfunction", "pkiss_function_mfe_controller", "pkiss_function_subopt_param", "pkiss_function_subopt_result", "pkiss_function_subopt_resulthandler", "pkiss_function_subopt_execfunction", "pkiss_function_subopt_controller", "pkiss_function_enforce_param", "pkiss_function_enforce_result", "pkiss_function_enforce_resulthandler", "pkiss_function_enforce_execfunction", "pkiss_function_enforce_controller", "pkiss_function_local_param", "pkiss_function_local_result", "pkiss_function_local_resulthandler", "pkiss_function_local_execfunction", "pkiss_function_local_controller", "pkiss_function_shapes_param", "pkiss_function_shapes_result", "pkiss_function_shapes_resulthandler", "pkiss_function_shapes_execfunction", "pkiss_function_shapes_controller", "pkiss_function_probs_param", "pkiss_function_probs_result", "pkiss_function_probs_resulthandler", "pkiss_function_probs_execfunction", "pkiss_function_probs_controller", "pkiss_function_cast_param", "pkiss_function_cast_result", "pkiss_function_cast_resulthandler", "pkiss_function_cast_execfunction", "pkiss_function_cast_controller", "pkiss_function_eval_param", "pkiss_function_eval_result", "pkiss_function_eval_resulthandler", "pkiss_function_eval_execfunction", "pkiss_function_eval_controller", "pkiss_function_convert_param", "pkiss_function_convert_result", "pkiss_function_convert_resulthandler", "pkiss_function_convert_execfunction", "pkiss_function_convert_controller"};
        
        Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
        
        for(String id: beanIds) {
            if(sessionMap.containsKey(id)) {
                sessionMap.remove(id);
            }
        }
        
        try {
            FacesContext.getCurrentInstance().getExternalContext().redirect("/pkiss");
        } catch (IOException ex) {
            log.warn("Could not redirect on reset: "+ex);
        }
    }

}
