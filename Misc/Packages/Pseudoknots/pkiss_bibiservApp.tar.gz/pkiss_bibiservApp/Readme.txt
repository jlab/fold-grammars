To save space, I removed the subdirectories 
	- "lib": I think it contains generic java libraries that can be restored simply by creating a new project and some copy and paste.
	- "dist": which should be the result of an "ant deploy" call
